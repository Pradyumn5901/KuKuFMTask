# The Forgotten Floor

# Episode 1: The Unseen Stop

The night‑shift badge clicked into the service console, and the elevator’s motor settled into its low growl. Rain hammered the glass doors of the lobby, a steady percussion that blended with the faint hiss of the building’s ventilation. Maya Alvarez slipped her gloved hand over the analog panel, the amber dials flickering like fireflies in a dark garden. She pressed the button for the first floor, thumb lingering on the lever as the car slipped into the shaft.

Inside the cab, oil scented the air, mingling with a metallic tang that seemed to come from the steel walls themselves. The strip of light above the doors pulsed in time with each floor’s ascent, a thin ribbon that breathed with the machinery. The needle climbed past six, hesitated on a blank notch that held no number, then lingered as the shaft’s fluorescence dimmed to a bruised violet.

A soft thump resonated through the steel, and the cabin shivered. The overhead bulbs sputtered, the emergency LEDs flaring to a cold white. For a heartbeat the motor’s hum dropped to a whisper, and the elevator stalled between the known and the unknown.

From deep within the shaft, a child's laughter slipped out—thin, warped, like a music box played in reverse. It curled around the metal, threading through the gaps of the doors, a sound that should not have existed in this place.

Maya lifted her phone, the recorder’s red light blinking steady. “Record of anomaly, 02:14 am,” she whispered, voice steadier than the tremor in her chest. “Elevator paused at a floor not listed on the panel. Lights flickered. Laughter heard. Over.”

She hit the intercom. “Javi, the car stopped between six and eight. Power flickered. I’m picking up… a sound.”

A muffled crackle answered. “Hold the doors. I’m coming down.”

The cabin lurched forward as the backup lights clicked on, the needle snapping to eight. The doors shivered open onto the service hallway, where a figure in a grease‑stained jacket stood under the humming fluorescents. Ethan Cho, the night‑shift lead, wiped oil from his forearm, his eyes already scanning the analog board with a practiced wariness.

“What did you see?” he asked, voice low, the edge of a lifetime spent in dark shafts.

Maya held up the phone. “The car stalled on an empty notch. The lights cut out. I heard a child’s laugh. I recorded it.”

Ethan’s jaw tightened. He lifted the cover of the control board, exposing a tangle of copper that branched toward a sealed panel in the far wall—no label, no schematic reference. “The panel won’t accept a command to stop at a floor that isn’t mapped unless someone’s tampered with the wiring,” he said, his tone flat, a hint of contempt for any excuse. “That loop—” he traced a finger along the rogue wire, “—doesn’t belong to any of Orion’s plans.”

Maya leaned closer, the recorder’s glow a small beacon. “Do you think it’s a fault?”

“Pranks die out before the night shift ends,” Ethan replied, his stare fixed on the mystery of the loop. “This building runs on its own timetable.”

He pressed a flashlight against the sealed panel, the beam catching a faint seam where metal met lead‑lined steel. “If something’s feeding the system a phantom floor, we need to know who’s behind it.” He glanced at Maya, the weight of responsibility evident in the set of his shoulders.

Maya nodded, feeling the recorder’s battery hum beneath her palm. “I’ll keep this logged. If anyone asks why the elevator stopped, they’ll have something to hear.”

The hallway lights steadied, the motor’s hum rising to its normal pitch. The indicator needle settled on eight, the blank notch between six and eight remaining an empty space on the dial. As the doors slid shut, a faint, distorted giggle brushed the metal once more, then fell silent.

In the shaft’s dim glow, a faint outline flickered on the concrete wall where the nonexistent seventh floor should be—a thin, door‑shaped silhouette, barely perceptible, as if waiting for a hand to turn the knob. Maya’s breath caught, and the recorder clicked off, leaving only the echo of that lingering giggle and the question: what, or who, lingered behind the ghostly doorway?


---

# Episode 2: The Loop Beneath the Panels

The shaft’s fluorescent hum settled into a low thrum as the elevator doors hissed shut on the eighth floor. Maya leaned against the cold steel rail, the recorder’s red diode blinking in the stale air. “Ethan, that wire you showed me—there’s still a loop feeding somewhere we can’t see,” she said, voice tight.  

Ethan crouched beside the analog control board, a headlamp throwing a narrow cone over dust‑caked switches. He brushed a fingertip over the tangled copper, then shrugged. “I’m telling you, it’s a glitch. The building’s old wiring behaves like a ghost when you stare at it long enough.” He jabbed a lever; the click echoed off concrete. “If it’s a prank, cutting power stops it. If it’s a fault, the diagnostics will flag it. I’m not here to chase fairy tales.”  

Maya’s jaw clenched. “The recorder caught something—a metallic scrape, like a pipe being dragged across steel. And the doors opened on a floor that doesn’t exist. I need proof, not a shrug.” She lifted the device, feeling its weight like a promise.  

Ethan’s stare lingered on the panel. After a moment he sighed, “Fine. I’ll give you something concrete. Not because I believe you, but because the board’s been acting up since week one.” He traced a line of copper that pulsed faintly with an amber glow, then veered away from the main harness and disappeared behind a rust‑stamped door labeled **SERVICE – DO NOT OPEN**.  

A sliver of light caught Ethan’s eye—a metallic glint seeping from a seam in the panel. He pried the door with a thin metal bar—a tool Maya kept in her pocket for jammed doors. The metal protested with a grating screech that reverberated through the shaft. Behind the panel, a conduit snaked into darkness, its outer sheath slick with condensation and lined with dull, lead‑gray coating that swallowed the flashlight’s beam. At the far end, a faint reflection flickered, catching Maya’s peripheral vision.  

She stepped closer, recorder still humming. The air grew cold, and a faint odor of burnt oil rose, sharp enough to make her throat tighten. “That’s not a pipe,” she whispered. “It’s a conduit, but why does it shine like that?”  

Ethan’s brow furrowed. “It isn’t on any schematics I’ve seen. Orion’s original blueprints only list utility runs to the eighth floor. This… this is something else.” He ran a gloved hand along the conduit, feeling a faint vibration, like a pulse.  

A sudden clang rang out—metal striking metal deep within the wall—followed by a low, breathy whisper that seemed to name her. “M‑—” the voice cut off, leaving a shiver in the air. Maya’s recorder captured the sound, its diode blinking erratically.  

The conduit’s end widened into a rusted safety hatch, the number **7** faintly etched on its corroded face. The hatch trembled, then cracked open with a sound like a scream of metal. Cold black mist poured out, curling around their boots and disappearing into the darkness beyond.  

Ethan stared, eyes wide. “That’s the floor we’ve been hearing about.”  

Maya knelt, fingers brushing a dark smear on the hatch’s lip. The oil‑black stain matched the slick residue reported in the 2004 accident file—a greasy film that had once coated the machinery of the forgotten floor. “This is it,” she breathed, the recorder’s click now a steady thrum.  

Without warning, the shaft lights sputtered, flared a brilliant white, then plunged into total darkness. The sudden void swallowed their breath. Maya’s thin metal pry bar clanged against the hatch as she tried to brace herself. The recorder emitted a sharp burst of static, the red diode flickering like a dying firefly.  

A disembodied voice cut through the black, raw and urgent: “Victor!”  

The words slammed into Maya’s ears, reverberating off unseen walls. The screen of her recorder flashed a final, garbled image before the darkness swallowed everything.  

She stood on the brink of the unknown, the cold mist curling tighter, the hatch yawning wider. What waited beyond the black, and why had a dead worker’s name been shouted from the void?


---

# Episode 3: The Manager’s Directive

The shaft lights hummed a low amber, casting thin bars across the oily vapor that clung to the cracked hatch. Maya slipped the handheld recorder into the pocket of her coveralls, thumb pressing the off switch so the red diode stayed dark. She could feel the weight of it, a silent promise to keep what Lena said to herself.

The service door thudded open and Lena Ortiz stepped in, badge catching the light on its polished edge. Her boots made a crisp click on the steel grating, and Ethan followed, flashlight sweeping the tunnel like a searching eye.

“Evening,” Lena said, voice clipped, eyes flicking to the hatch where the black mist still hovered, a thin veil over the steel. “I’m here for the routine seal check. Keep this area clear until the board signs off.”

She moved toward the panel, hand brushing the exposed wiring that Ethan had flagged earlier. “The analog panel can be forced to stop on a phantom floor if someone’s meddled with the hidden wiring,” she said, pausing. “That’s why we treat this as a mechanical glitch, not a… whatever you’re hoping it is.”

Maya lifted the recorder just enough for the mic to catch Lena’s words, then slid it back into her coat, the click barely audible over the distant hum of the building’s ventilation.  

“Stay away from the hatch until we get official clearance,” Lena continued, tone terse, the kind that left no room for questions. “No one descends unless the engineers are on site tomorrow. Understood?”

Ethan nodded, his jaw set. Maya’s recorder captured the short, hard syllables, the way Lena’s eyes narrowed at the flicker of the light above the hatch. The tension in her voice was a thin wire stretched taut.

A muted buzz cut through the stale air as Lena’s phone vibrated on the metal rail. She glanced at the screen, eyes narrowing further. The message was a string of characters, the top line flashing: **ORION‑SEC‑7F**. Below it, encrypted text pulsed, half‑visible: *“Protocol engaged. Archive access pending.”* She slipped the phone into her jacket without a word, the device’s soft chime echoing off the concrete walls.

“Anything else, Maya?” Lena asked, voice flat, as if the brief exchange had already been logged in her mind.

“Just the usual checks,” Maya replied, keeping her tone even while the recorder’s red diode flickered once, then stayed dark. She watched Lena’s shoulders tense, then relax as she turned toward the stairwell.

“Make sure the hatch stays sealed,” Lena said, the final directive hanging in the damp air. “We’ll handle it in the morning.”

The manager’s boots disappeared around the corner, the echo fading into the night‑shift silence. Maya lingered a moment longer, the recorder’s tiny weight a reminder of the secret she now carried.

A soft click announced the arrival of Dr. Selene Patel, her coat dusted with fine ash from the building’s old boiler rooms. She paused at the entrance, eyes scanning the hallway with practiced precision.

“Good to see you, Maya,” Selene said, voice warm but edged with urgency. “I’ve been combing the municipal archives for anything on the 2004 incident. All I’m finding are gaps—files that should be here but aren’t.”

Maya lifted her chin, the recorder still silent in her pocket. “The hatch is still open. The mist… it’s different from the usual oil residue.”

Selene knelt, inhaling the faint metallic scent. “Lead‑lined steel, no signal penetration—exactly what the reports described for the sealed level. Whoever covered it up wanted it invisible, not just forgotten.”

A distant clank resonated from the elevator shaft, a reminder of the building’s restless mechanisms. Selene stood, pulling a slim notebook from her bag.

“We’ll need to get the original schematics,” she said, tapping the page. “If the board wants to seal it tomorrow, they’ll need proof of what’s down there. And we’ll have to find those missing archives before the next power dip.”

Maya felt the recorder’s off switch click beneath her fingers, the tiny sound swallowed by the humming lights. She glanced back at the hatch, where the mist now drifted like a slow, silent river, and wondered how deep the concealment ran.

As Selene turned to leave, a final buzz sounded from Lena’s phone, a soft vibration that seemed to linger in the air. Maya’s eyes snapped to the hallway doorway; the manager’s device displayed a single line of text: **“Floor 7 – activation pending.”** The words flickered, then vanished, leaving a cold echo in the shaft.  

What would happen the moment the power slipped again?


---

# Episode 4: The Surge

02:45 am. The shaft lights trembled, a soft violet flicker that stretched across the concrete like a pulse. Maya pressed the recorder against her chest, its silent weight a reminder of every missed sound. A low hum rose from the elevator’s motor, a sound that seemed to sync with her own heartbeat.  

Javi Ramos slipped a flashlight from his belt, the beam cutting a thin scar through the gloom of a maintenance closet. Behind a stack of rust‑caked panels he uncovered a door half‑swallowed by grime. The numeral “7” was etched faintly into the metal, the digits smoothed by years of neglect. He brushed the dust away, feeling the cold bite of the steel.  

“Looks like they sealed it from the inside,” Javi muttered, his voice barely rising above the shaft’s sigh. He nudged the door; it shivered, exhaling a draft that smelled of burnt copper and ozone.  

Footsteps echoed down the tunnel. Dr. Selene Patel emerged, her coat dusted with a fine, metallic film that clung to the fibers like frost. In her satchel she cradled a yellowed newspaper clipping, the headline stark in the dim light: *Fire Ravages Ridgeview Hall – Twelve Lost*. Below, the date read 2004, the ink faded but still legible.  

“Thank you, Javi,” Selene said, eyes flicking to the rusted portal. “The archives list a fire, a cover‑up… nothing about a sealed level. That’s why I’m here.” She spread the clipping on a nearby metal crate; the paper crackled as the emergency lights flickered, then dimmed. A grainy photograph showed a stairwell reduced to ash, its railing twisted like a broken spine.  

Maya stepped out of the elevator car, the doors sighing shut behind her. “Do you think the surge we felt earlier could be… something else?” she asked, voice thin over the whine of the ventilation fan.  

Selene lifted a handheld EMF meter, the needle quivering. “If the wiring was tampered with, the charge could be stored in the steel framework. It acts like a capacitor—once the circuit closes, the energy releases in a flash.” She glanced at the door’s frame, where an unfamiliar brass insignia glinted—a stylized gear entwined with a serpent, half‑eroded but unmistakable. “That symbol isn’t on any official plans. It could be a marker left by whoever built the hidden floor.”  

A sudden, almost imperceptible dimming washed over the shaft lights—a brief, trembling flicker that hinted at an incoming outage. The elevator car shivered, its panel lights sputtering before the whole system fell into darkness. The only illumination came from Javi’s dying flashlight and the faint glow of the EMF meter’s red diode.  

A metallic clang reverberated as the elevator halted. The car’s doors slid open on their own, revealing a narrow hallway that stretched beyond sight, its walls lined with lead‑lined steel doors—each identical, each mute. The brass insignia above the rusted door glimmered in the weak light, casting a thin halo.  

From the darkness beyond the doorway a sudden surge of white‑hot static erupted, a blade of light that sliced the air with a deafening crack. The blast struck Selene squarely; her coat ignited in a flash of static, hair snapping like live wire. She crumpled to the concrete, the EMF meter skidding across the floor, its casing blackened, a thin plume of smoke curling upward.  

“Back!” Javi shouted, but his words were swallowed by the roar. The hallway flickered, then fell silent except for the hiss of cooling metal. The elevator doors slammed shut with a resonant clang, echoing down the shaft like a verdict.  

Maya stood frozen, the recorder’s weight suddenly oppressive. She knelt beside Selene’s still form, eyes drawn to the brass insignia. Etched beneath the gear, barely visible, were three letters: **E C H**. A cold draft slipped through the doorway, carrying the faint scent of burnt metal and a whisper that seemed to echo from the walls themselves: *…listen…*  

She lifted Selene’s notebook, a hurried scrawl catching her eye: *Residual echo—might survive physical death.* The words pulsed in her mind, a question rising like a tide.  

If Selene’s consciousness could linger as an echo, could that echo guide her through the hidden floor’s darkness? And what did the mysterious insignia mean for the secrets still buried beneath Ridgeview Hall?


---

# Episode 5: The Echo Protocol

The service bay was a slab of cold steel and the hiss of a dying generator. Maya stood amid the humming machinery, her breath forming a thin cloud in the stale air. The recorder, a battered black cylinder, lay in her jacket pocket, its weight suddenly oppressive as if it carried the weight of the world. Beside it, the EMF meter blinked a red pulse that trembled with each breath Maya inhaled. Her eyes flicked to the cracked panel that framed the elevator controls; a jagged shard of glass caught the weak light, reflecting a distorted version of her own face.

A broken mirror in the corner of the bay—left over from the blast that killed Selene—caught her attention. She leaned over the shattered surface, watching her own reflection ripple as a gust of cold air pushed through the open hatch. A flicker of something behind her face made the hairs on her arms stand. Maya's fingers tightened around the recorder as she forced herself to look back at the notes on the clipboard.

Selene had left her notebook on the console, pages torn but legible. The margin of a page was scratched with a hurried scrawl: **Residual echo—might survive physical death**. The ink had faded to a gray, but the words pulsed in Maya's mind like a second heartbeat. Beside the sentence, a symbol stared back: a gear wrapped in a serpent’s coil, the letters **E C H** etched beneath. It matched the insignia on the maintenance badge that hung from the wall above the shaft—a badge Maya had pulled from her pocket earlier, the brass worn thin by years of handling.

The note continued, slanted: *Binding the consciousness to the lead‑lined steel of the sealed floor will anchor the echo, but the anchor can also be a prison.* Maya’s pulse quickened. The recorder’s battery icon was dim, the screen flickering in the dark. She felt the EMF meter’s needle twitch again, a faint vibration that seemed to echo from the walls themselves.

She stared at the page. Selene’s last words were a question as much as a warning: **Will the echo guide you, or will you be guided by it?** The words were written in a hurried script, as if Selene had anticipated that she would be reading them in the aftermath of the static surge. The whisper that had drifted through the service hall when Selene fell seemed to return, faint as a breath on her ear: *…listen…* Maya's hand hovered over the page, then hovered over the badge on the wall, the metal cold under her fingertips.

Outside the bay, the elevator lights dimmed, the emergency generator's sputter a steady hiss. The timestamp on the wall’s clock ticked toward 02:48 am. Maya felt a shiver run up her spine, not from the cold but from the thought that the protocol could bind her own consciousness to the same steel that had trapped Selene’s. She had lost the only mentor who had shown her how to navigate the building’s hidden layers. Now she held the key to a new kind of presence—one that could be called back, but also one that might claim her.

Maya's hand shook as she closed the notebook. The recorder’s battery icon flashed red. She glanced at the broken mirror once more; her reflection seemed to lean inward, a faint outline of a shape behind her. She heard the whisper again, clearer this time: *…echo…* The EMF meter’s needle quivered to a dead stop. She pressed her palm to the metal of the badge, feeling a faint pulse in the brass that seemed to match the beat of her own heart.  

A cold draft slid through the hatch, the scent of burnt metal lingering. Maya understood that the hidden floor was not just a forgotten space; it was a place where consciousness could be tethered. She knew what Selene had left behind, and she feared the same trap.  

She turned to the service door, the metal seam of the hatch rusted and sealed. A new question hung in the air, sharper than the last: **If the echo returns, will it guide Maya, or will Maya be guided—and possibly lost—to the seventh floor?**


---

# Episode 6: The Hidden Stop

The shaft exhaled cold, its concrete ribs humming faintly as the power rails flickered to a dim amber. Maya’s gloves pressed against the metal railing, the soles of her boots finding purchase on a slick, wet floor that reflected the weak emergency lights. The elevator’s last motor whir had dissolved into a low, endless hum that seemed to seep into the walls. Her headset crackled, a jagged voice saying, “Power loss… 3% down. Stay clear.”

She hit the emergency button, and the red LED flashed like a pulse against the night. The doors shuddered open, revealing a corridor that stretched into a gray void. The walls were a patchwork of weather‑torn steel panels, each a mirror of the last, coated in thick layers of lead that swallowed radio waves. A few doors along the line bore a worn brass plate, the letters ECH etched in a serpent‑like script that seemed to writhe under the dim light.

Maya’s heart thudded against her ribs. The recorder on her belt vibrated, its battery icon blinking a stubborn red. She pressed the mic button, and the static hiss drowned a single whisper that slipped through the metal: *…oil…* The air tasted of cold metal and a faint metallic tang that seemed to seep from the very walls.

She stepped forward, boots sinking into a floor that shuddered with each tread. A low clang rang, a metallic note that seemed to echo back from the sealed steel. Her ears caught a distant, almost inaudible hiss—like a whistle blown through a pipe that had long since stopped breathing. She stopped, listening. The hiss resolved into a sharp crack, the sound of a floorboard splintering under invisible pressure. The air filled with a sour, acrid scent—burnt rubber, the ghost of a fire that had once surged through the hidden level.

A flash flared in her mind: a worker’s hand, slick with oil, slipping on a wet patch, the floorboards groaning, the crack spreading. The image was not hers, but it was vivid, the way a memory can be felt more than seen. A sound—an instant burst of heat and then a sudden, absolute silence—filled the space around her, the echo of a scream that had never been heard by anyone alive.

Maya turned toward the nearest door, its brass plate cold and rough under her palm. She pressed her fingers into the metal, feeling a faint tremor that matched her own pulse. The walls seemed to lean, the lead panels absorbing the vibration. She could taste the metallic tang on her tongue, the aftertaste of the hidden floor’s secret.

She inhaled sharply, the breath heavy with the scent of burnt rubber and the faint, metallic taste that clung to her teeth. She could feel the building's heartbeat—a slow, uneven thump that resonated with every footfall. The air around her grew thicker, as though the corridor were a living thing, holding its breath.

Her recorder's mic caught a sudden burst of static, a crackle that felt like the shattering of glass. The flash in her mind intensified: the splinter of wood tearing away, the air filling with a hot, burning smell, then an abrupt, hollow silence as if the floor itself had been devoured by flame. The memory ended with a soundless scream, an echo that lingered in the back of her mind.

Maya swallowed, her throat tight. She stared at the brass plate, its serpent‑inscribed letters swirling in the dim light. The corridor stretched ahead, each door a mirror of the last, each promising the same unseen terror. She could turn back, retreat to the safety of the night shift, but the echo within her told another story—a story of a hidden floor, a forgotten tragedy, a chance to step into a place that could either reveal the truth or consume her.

She heard a faint hiss again, this time not from the walls but from within her own thoughts: *…don’t stop.* The whisper carried a weight she could feel in her bones.

The recorder’s battery icon blinked a final red pulse, then dimmed. The corridor's darkness pressed against her, the air heavy with the scent of burnt rubber. Maya lifted her hand, fingers trembling, and pressed the brass plate. The door sighed open, the metal groaning as if relieved after a long hold.

The hallway beyond was a black void, the only light coming from the faint glow of a single emergency bulb. As she stepped forward, the echo of her footsteps sounded like a drumbeat, each tap a question she could not yet answer.

She paused, the weight of the unknown pressing against her chest. A new question settled in the space between her ribs, sharper than the last: **What will the seventh floor reveal if she crosses that threshold?**


---

# Episode 7: The Seventh Blueprint

Ethan’s fingers slipped over the brittle edge of a paper that had been lodged in a vent long enough to be a relic of the old maintenance crew. The parchment trembled as he pulled it free, dust settling onto the steel table in a thin white cloud. Lines, once crisp, were now blurred where rain and time had etched their marks, but the outline of a floor that the modern maps denied still held its shape.

“Level 7 – Restricted,” he whispered, the word thick with unease. The words were carved beneath a red circle that seemed to pulse with a warning of its own. Next to the schematic, in cramped scrawl, were the initials O.R.H., unmistakably Orion Rural Holdings.

Maya, recorder dangling from her neck, stared at the map. The battery icon on her device blinked a stubborn red. “That’s the same mark as the one on the brass plate,” she said. “The one that’s still there when we walk up to the hatch.”

Ethan nodded, eyes narrowed. “Someone drew that over the plans. Maybe a last‑minute note. Whoever did it knew the floor existed, or at least wanted to keep it that way.”

They leaned over the map, the shaft’s dim light flickering against the paper. The red circle seemed to draw a line from the hatch to the very center of the blueprint. It was a line that could be a warning, a boundary, or a key.

Ethan’s flashlight swung toward the vent and stopped on a face—pale, half‑formed, pressed to the grille from inside, mouth open mid‑word. Maya yelped and hit the table. Ethan jerked the beam back. Only dust, turning slowly, and a smear of soot where the cheek had been.

“Look at the corners,” Ethan said, pointing to a square in the lower right of the plan. “It’s unmarked, but the line runs straight through it, and there’s that same red circle on the blueprint’s edge.” He tapped the circle again, a sharp, almost audible hiss escaping the metal. “If we can get the elevator to register Level 7, the system might trigger that panel. But the wiring’s been sealed for years.”

Maya’s throat tightened. “I remember Selene’s notes about the Echo Protocol. She said the sealed steel could anchor a consciousness, but she didn’t finish the thought. If the elevator stops there, the memory flash could be… dangerous.”

Ethan swallowed. The corridor beyond the hatch was a long, dark void; the emergency bulb sputtered, throwing brief glints of light onto the concrete walls. The air smelled of rust and old smoke. The silence was punctuated only by the hiss of old pipes and the distant hum of the building’s HVAC.

“Maybe we should just open the hatch and see,” Maya said, her voice low. “If the blueprints are wrong, we’ll know. If they’re right, the elevator will find a way to stop.”

Ethan pulled a thin rope from his pocket and looped it around the brass plate, the ECH insignia gleaming faintly. He lifted the hatch, and a cold wind rushed out, carrying with it a metallic taste that made Maya’s skin prickle.

Inside, the corridor stretched on, a black line of concrete and steel. The emergency bulb blinked out, plunging the space into darkness save for a faint glow from a vent. Ethan’s flashlight cut a narrow beam ahead, illuminating dust motes that floated like ghosts in the air.

Then the motes stopped. For one second they hung in the beam in the shape of a woman—shoulders, the hem of a long coat, a raised hand—before a gust scattered them. Maya’s recorder clicked on by itself: static, a breath, one word too faint to trust. *Wait.*

“Watch your step,” he murmured. “We need to keep the elevator’s control panel in sight. If the system refuses to register Level 7, we’ll have to use the Echo Protocol.” He turned to Maya, eyes sharp. “Do you hear that?”

Maya nodded. The hiss seemed to come from the walls themselves, a low, continuous sigh. Her recorder’s red light pulsed once, twice, like a heartbeat in the dark.

They moved forward, each step a drumbeat


---

# Episode 8: The Whispered Ledger

The tunnel was a cold, humming artery beneath Ridgeview Hall, its concrete walls slick with the late‑night mist that clung to the city’s fog. Maya’s footsteps echoed off the metal grating as she slid her recorder onto her knee, the red light steady, a silent witness to the darkness ahead. The clock on the service panel read 02:50 am, a time that felt both absurdly long and painfully brief.  

A faint metallic clink rang through the corridor, sharper than the usual hiss that had haunted the shaft. It was the sound of a tiny bolt turning, a subtle cue that the hidden wiring was close. Maya’s fingers tightened on the handle of her toolbox; she had heard this clink before, a whisper that the seventh floor was not just a myth.  

“Victor Hale?” she called into the black, the words barely louder than her own breathing. The figure that stepped from behind a service door was taller than expected, the silhouette of a contractor’s hard hat glinting in the weak bulb. He was a man who had been hired to “clean up” the hall, but the way his eyes flicked around the tunnel made Maya wary. He held a notebook in one hand, the other cradling a small metal key that looked like a relic of a forgotten era.  

“You’re still on the clock,” Victor said, his voice low and even. “Thought I’d catch you before the next blackout.” He flipped open the notebook to a page with a single line etched across the paper: a broken gear, the same emblem that had appeared on the brass plate of the ECH insignia she’d seen on the elevator’s control panel.  

Maya’s pulse quickened. “What’s that?” she asked, but the question felt like a gunshot.  

Victor smiled, a tight line that didn’t reach his eyes. “From Orion Rural Holdings. A symbol of the old guard’s secrecy. They used it to mark their own records.” He slid the notebook across the floor, placing it beside a small, rusted key. “I’ve found a panel behind the service doors that’s been sealed off. It’s wired to the elevator’s control board. The key fits into it, and if you turn it, the panel opens a new path for the cables.”  

He pressed the key into Maya’s palm. The metal was cold, its surface etched with tiny scratches that matched the gear in the notebook. “But there’s more.” He lowered his voice to a conspiratorial whisper. “In the ledger that sits in the basement, buried under a lock that’s been sealed since 2004, there’s a line that says ‘Payouts to Fire Suppression.’ It’s not a ledger you can read with a pen. It’s a ledger that reads you.”  

Maya stared at the key, then back at the notebook. The broken gear seemed to shimmer, its teeth catching the faint light. She felt a prickle run up her arm, like a static shock. The elevator’s panel glowed faintly, the analog dials ticking in the background.  

“Why are you giving me this?” Maya asked, her voice a breath in the stale air.  

Victor’s eyes flicked to a shadow behind the panel, a flicker that seemed almost... spectral. Maya followed his look. In the panel’s dark glass, a scorched sleeve reached past her own reflection toward her shoulder. She spun. Nothing behind her but the humming tunnel, and frost fading on the grating. “Because the building is listening,” he said. “And whoever holds the key can make it hear back.” He lifted his chin. “And there’s a warning.” He slid the notebook toward her, the page with the broken gear face up. “Do not dig too deep. The echoes you hear will try to lure you.”  

Maya turned the key over in her hand, feeling the weight of it. It wasn’t a simple key; it was a key to a circuit that could force the elevator to register the seventh floor. The night‑shift crew had never had that option. The knowledge she held could alter the building’s fate, or trap her in a memory‑filled labyrinth.  

She slid the notebook into her jacket, the gear’s metal clicking softly against her skin. “I’ll need to check the basement,” she said, the words steady but edged with uncertainty.  

Victor nodded, a faint smile playing on his lips.


---

# Episode 9: The Digital Ghost

The sub-basement office smelled of burnt dust and the ozone tang of overheating servers. Javi Ramos sat hunched over a modified laptop, the screen’s blue glow carving hollows under his eyes. On the display, a video file played in a silent loop: grainy, shaky footage of the sealed hallway behind Hatch 7. The lead-lined steel doors, the faint hiss of condensation on cold metal, the absolute void where light should have bounced off a floor.

It wasn’t much. To anyone else, it was sensor noise or editing error. To Javi, it was a hammer. He scrolled through the comments on *Ridgeview Echoes*, his anonymous blog that usually attracted nothing but complaints about the library’s WiFi. Since midnight, three posts had appeared.

“Is this the camera glitch spreading again?” User Klow12 asked.
“Deepfake. Check the metadata,” User TruthSeeker replied.
“Why does the timestamp say 02:48 on the 12th, when the clock in the background is running slow?” User CuriousGeo typed.

Javi frowned. He hadn’t changed the metadata. He opened the file properties, his breath holding in his throat. The creation date was today. The modification date was today. But the embedded metadata he hadn’t touched claimed a camera serial number that didn’t exist in Ridgeview Hall’s inventory. It was a ghost file, generated by a device the building didn’t own.

His phone buzzed against the desk, a single vibration that felt violent in the quiet room. It was a text from an unknown number. No emoji. No pleasantries. Just a string of coordinates and a sentence.

*He buried it in the dirt. Check the maintenance shaft behind the north water heater. The ledger is in the foundation. – S.*

Javi’s heart didn’t hammer; it synced. He tapped the screen, isolating the IP address. It was routed through three proxies, all ending in a dead drop associated with the building’s internal maintenance server. This wasn’t a prank. This was a signal. *S.* Selene. He had seen the black scorch marks on her coat, had held the notebook that smelled of ozone. The chance this was a hoax was high, but the detail about the water heater? Javi hadn’t seen that area unless he was looking for a place to hide. Someone knew.

He looked at the video again. In the loop, the faint hiss of the hallway now seemed to match the low-frequency drone coming from his phone’s speaker. It was a trick of the mind, or the building was listening, as Victor had claimed. If the building was listening, who was sending the message? And why now?

Javi closed the laptop, the screen going black. In the reflection of his own face, he looked older, thinner, haunted. He couldn’t do this alone. Not anymore. He stood up, his legs steady, and grabbed his jacket. The air in the office suddenly felt thick, charged with a static that made the hairs on his arms stand up.

He opened the door to the main corridor. The hallway lights were flickering, a sickly yellow pulse that synced with the elevator’s distant hum. At the far end of the corridor, near the service exit leading to the sub-basements, a figure stood in the shadows. It was Ethan. He wasn’t moving. He wasn’t breathing. His back was to Javi, his head tilted slightly to the side, looking at the wall like he was listening to a frequency only he could hear.

Javi took a step forward, his hand gripping the doorknob. “Ethan?”

The figure did not turn. But the light from the flickering overhead bulb cast a long, distorted shadow on the floor, and the shape of that shadow wasn’t human. It was elongated, stretching out toward Javi like a spider’s leg, ending in a pair of sharp, twitching points that looked disturbingly like ears.

Javi backed away, the knot in his stomach tightening. The elevator hummed, rising in pitch, and from the depths of the shaft, a single, wet footstep echoed in the darkness.


---

# Episode 10: The Ledger of Ashes

The concrete stairwell at the south edge of Ridgeview Hall exhaled a cold draft that smelled of rust and old oil. Maya's boots clanged against the cracked tile as she followed Ethan's narrow beam of light deeper into the storage basement. The fluorescent tubes above flickered in a sickly rhythm, each pulse echoing the distant hum of the elevator shaft.

“Key fits the old security lock on the back wall,” Ethan said, turning the battered metal key Victor had given her. The key’s teeth were smooth from years of neglect, but it turned with a reluctant click that sent a shiver through the metal door.

Inside the cramped room, metal shelves sagged under the weight of yellowed manuals, dented toolboxes, and a single steel safe that stared back like a tomb. Dust swirled in the flashlight’s cone, catching on a spider‑web of cobwebs that clung to the safe’s corroded surface.

Maya knelt, wiped a film of grime from the analog keypad, and felt the raised numbers beneath her fingertips. A fragment of Selene’s echo whispered in her mind, a hushed phrase that had slipped through the static on the night of the surge: “Seven‑four‑two, the fire’s last breath.” She set the dial, held her breath, and pulled the lever. The lock protested with a soft groan before the heavy door swung inward.

The safe’s interior was a shallow cavity lined with blackened wood. Resting on a tray was a leather‑bound tome, its cover stamped with Orion Rural Holdings’ emblem—a rearing horse over a broken gear. The pages were thick, yellowed, and brittle, each line scrawled in cramped ink that had bled into the fibers over decades.

Ethan lifted the lid, and a gust of cold air escaped, carrying the faint scent of burnt cordite. “That’s the master payout ledger,” he said, voice low. “The one they hid after the fire. It’s bigger than the little book we saw in the service panel.”

Maya opened to the first page. Entries began in January 2004, cataloguing “maintenance overtime” and “safety inspections” with amounts that never added up. In the margins, cryptic notations—“P‑12,” “E‑7”—pointed to a marginal note in ink so faded it seemed to dissolve under the flashlight: “Cover‑up approved – O.R.H.”

She traced the letters, the paper crackling softly. “Orion Rural Holdings,” Ethan murmured, his brow furrowing. “But why sign it? To own the lie?”

The ledger’s dates marched forward, aligning with the night of the accident. June 12, 2004, 02:37 am—a timestamp that matched the moment the building’s emergency logs went dark. The final entry, dated that night, listed a single payout: “$12,500 – Victor H. – Accident compensation,” followed by a hurried, smudged signature: **O.R.H.** The ink was still warm to the touch, as if the pen had been set down moments ago.

A sudden pressure pressed against Maya’s eardrums, the way air thickens before a storm. The fluorescent tubes sank to a brown glow, and every page of the ledger lifted at once and settled again, as if something had exhaled across them.

“Vents,” Ethan said, already backing toward the door. “If the dampers on three are shut, this level loses air. I’ll reopen them.” He pressed the radio into her hand. “Stay on channel two.”

His footsteps faded up the stairwell. Maya tucked the ledger inside her jacket, the leather cold against her ribs, and her phone buzzed: a message from Javi, forwarded without comment. *He buried it in the dirt. Check the maintenance shaft behind the north water heater. – S.*

The north water heater stood twenty metres away, through the utility‑room door.

Behind her, the safe door swung shut on its own. The dial spun and settled—seven, four, two—and from inside the empty steel came the soft, unmistakable scratch of a pen.


---

# Episode 11: Below the Boiler

02:59 am. The basement’s utility room smelled of rust and the lingering ash of June 2004, a sour metallic tang that clung to the concrete like a memory. Maya crouched beside the hulking water heater, its steel belly pitted and cold to the touch. She pressed the recorder against her chest; the red LED blinked a steady rhythm, a pulse that matched the thrum of the building’s night‑shift heart.  

“Ethan, you still on the third floor?” she whispered into the mic, the breath fogging the recorder’s mic grill. The reply crackled, distant and hoarse: “Just finished the vent check. You good down there?”  

Her gloved hand brushed a seam in the heater’s rear panel, a thin line of rivets that didn’t belong to the original schematics. She slipped a flathead between them, feeling the metal give with a reluctant sigh. Behind the panel lay a locked mechanical hatch, its surface stamped with a serial number that pulsed faintly in the dim light: **XR‑7‑8421**. The broken‑gear emblem was etched into the hatch’s lip, the same silent signature of Orion Rural Holdings that had haunted every file they’d uncovered.  

Maya’s fingers traced the number, and a subtle vibration traveled up the steel, a low, rhythmic hiss that reminded her of hydraulic pistons shifting under pressure. It was not the familiar elevator whir she’d heard before; this sound rose and fell like a distant breath, as if the building itself were inhaling through hidden chambers.  

She pried the hatch open with a crowbar, the metal grinding against concrete. A narrow stairwell yawned behind it, its walls lined with antiquated pipework and bundles of wiring that seemed to pulse in time with the hiss. A thin rope of condensation clung to the iron railing, each step echoing a hollow thunk that reverberated up the shaft.  

Halfway down, she spotted a rusted metal cabinet bolted to the wall. Its door was ajar, revealing a leather‑bound logbook, the cover browned and brittle. Maya brushed the dust from the title: **“Maintenance Log – Level 7”**. She opened it to a page dated June 2004. The entry read:  

*06/12/2004 – 02:41 am – Level 7 inspection. All systems nominal. Noted anomalous pressure reading on conduit XR‑7‑8421. No further action required.*  

Below the entry, in a hurried scrawl, someone had circled the word “anomalous” and added a single line: **“E‑9”**. Maya’s eyes flicked to the margin, where a faint imprint of the broken‑gear emblem was pressed into the paper, as if a heavy hand had pressed it there.  

A sudden hiss grew louder, the hydraulic sound now threaded with a metallic clank that seemed to come from deeper within the shaft. Maya swallowed, feeling the cold air bite at her cheeks. She lifted the recorder, her voice low:  

“Found a hidden hatch behind the heater, serial XR‑7‑8421. Stairwell leads to a service shaft. Logbook shows a Level 7 inspection just before the fire, with an odd pressure note and a cryptic ‘E‑9’. The hiss is getting louder—something is still moving down there.”  

She set the recorder down, the device capturing the faint echo of the hiss as it bounced off the stairwell walls. The metal door at the landing ahead was bolted shut, but the hinges trembled with each pulse of the sound. Maya pressed her palm to the cold surface; a faint vibration traveled through the steel, matching the rhythm of the hiss.  

A faint, sickly green glow seeped through a crack in the door, illuminating a control panel frozen on “ON”. The analog dials flickered as if the building were holding its breath. Maya’s breath fogged in the chill, and she heard, for the briefest instant, the echo of a voice—no longer Selene Patel, but a recorded fragment of her research, filtered through the building’s memory:  

*“Seven‑four‑two, the fire’s last breath…”*  

Maya’s fingers tightened around the door handle. The lock gave a soft click, and the door creaked open just enough to reveal a dark hallway lined with steel doors, one of them stamped boldly with the number **7**. Beyond it, the hydraulic hiss rose to a roar, a low grind that seemed to swallow the faint green light.  

She recorded a final breathy note:  

“Ethan, I’m at the Level 7 door. Something’s awake, and the pressure reading points to XR‑7‑8421. If this is a trap… I need to know what ‘E‑9’ means before I step through.”  

The recorder clicked off as the door swung wider, the hiss pulsing like a heartbeat. In the shadowed doorway, a faint smear of fresh oil glistened on the floor, as if a hand had just brushed past. Who—or what—had left it there?


---

# Episode 12: The Ink of the Unseen

The stairwell breathed a cold, oily sigh that clung to Maya’s coat as she pushed the steel door ajar. Behind her, Ethan’s boots whispered against the grated concrete, the sound thin and deliberate in the narrow tunnel. A weak lantern swung from his wrist, casting jittering amber on rows of aging conduit pipes, their copper veins exposed like dried veins in a corpse.  

“Did you feel that?” Maya whispered, the words frosting in the chill.  

Ethan paused, his gaze fixed on the faint green glimmer seeping from the crack in the Level 7 doorway. “It’s the vent humming,” he said, though the tone of his voice hinted at something else—an unease he rarely showed.  

They followed the maintenance corridor that ran parallel to the elevator shaft, the walls slick with a thin film of fresh oil that caught the lantern light and turned it into a greasy sheen. The smell was metallic, almost sweet, and it seemed to pulse in time with the low hydraulic hiss that emanated from the hidden hallway beyond.  

At the far end of the tunnel, a rusted metal box was bolted to the wall, its latch corroded shut. A faint imprint lingered on the surface, a dark smear that resembled a handprint but lacked the usual ridges of a fingerprint. Maya knelt, running a fingertip over the ghostly mark. The oil made it glisten, and as she pressed, a faint phosphorescent glow flickered around the edges, as if the imprint itself were still warm.  

Inside the box lay a battered notebook, its cover a faded blue leather cracked by time. The first page was already open to a dated entry: **June 2004 – Level 7 Inspection**. The ink was dark, the script cramped. Maya read aloud, her voice echoing off the steel:  

*“Pressure reading on conduit XR‑7‑8421 stable at 4.2 bar. Lead‑lined steel integrity confirmed. E‑9 notation pending further analysis. No further remarks.”*  

She turned the page, expecting more notes. The paper was blank except for a jagged blot of ink that stretched across the margin like a hand dragged through black water. The smear pulsed faintly, a phosphorescent residue that seemed to appear only now, in the present moment.  

Ethan leaned in, his breath fogging the paper. “That isn’t 2004,” he said. “It’s… fresh. Something’s still writing.”  

Maya lifted the recorder from her pocket, pressed the mic to the notebook, and whispered, “Record. This mark appeared when we opened the box. It matches no known badge.” She flipped the notebook to the back, where a torn corner revealed a faintly visible number: **# B‑742‑9**. The same sequence that had opened the safe in the basement.  

“B‑742‑9,” Ethan muttered, eyes narrowing. “Victor’s payout entry used 742. That extra ‘9’ could be a reference to a specific valve or panel.”  

Maya’s mind raced. She recalled the maintenance log’s cryptic “E‑9” line. “E‑9 might not be a code at all,” she said. “It could be ‘E’ for ‘Emergency’ and ‘9’ for valve nine on the XR‑7‑8421 line. If someone opened that valve, the pressure would spike, triggering the hidden alarm we heard on the lantern’s flicker.”  

She tapped her tablet, pulling up the schematics they’d downloaded from the building’s archive. A tiny valve labeled **V‑9** sat on the same conduit diagram, marked with a red circle and a note: *“Manual override—use only in emergency.”*  

Ethan’s hand hovered over the tablet. “Someone’s been resetting that valve, maybe to keep the floor pressurized enough to… hold a presence.”  

A sudden shudder ran through the steel door at the end of the hallway. The green glow flared, and a faint outline of a man in a hard hat stepped into the doorway, his features flickering like a dying projector. The figure’s face was indistinct, but the outline of a badge glowed with the same phosphorescent hue as the handprint.  

“It’s a residual echo,” Maya said, voice trembling. “Selene’s research warned us that the floor only manifests when the building’s old fire alarm frequency aligns with the pressure system. That pulse we heard… it’s the floor waking up.”  

Ethan raised his recorder, capturing the low hum that matched the building’s dormant fire alarm. “If we don’t shut V‑9, the floor could stay active, trapping whatever’s left of those workers.”  

Maya glanced at the smeared handprint, the number **B‑742‑9** still glowing. “We need to find that valve and cut the pressure before the next surge. And whoever left that mark… they wanted us to see it.”  

She slipped the notebook back into the box, closed the latch, and turned toward the hallway. The green light pulsed once more, then dimmed, as if waiting for a decision.  

The lantern flickered, and a soft click echoed from the far wall—a hidden panel beginning to unlatch.  

Maya stared at the opening, the recorder still humming, and asked the empty hallway, “What’s pulling the lever, and why does it want us to finish what was started in 2004?”  

The panel creaked wider, revealing a narrow conduit lined with a brass valve bearing the same **V‑9** inscription, its handle turning of its own accord. The hiss rose to a roar, and the faint silhouette of the hard‑hat figure steadied, eyes fixed on the valve.  

A single, wet footstep echoed down the shaft, louder than any they had heard before.


---

# Episode 13: The Archive’s Echo

The service shaft’s hum fell to a low thrum as Maya pulled the panel shut, the metal doors sealing the hidden conduit behind her. Ethan’s boots echoed on the concrete, each step a metronome to the building’s restless pulse.  

“V‑9 is still turning on its own,” Maya said, eyes fixed on the brass handle that shivered like a nerve under skin.  

“It feels like someone’s hand is cranking it from the other side,” Ethan replied, wiping oil from his forearm. “If we don’t stop it now, the pressure could lock us in.”  

A distant clatter announced Javi’s arrival. He lugged a battered laptop and a portable inverter, the screen’s ghostly glow reflecting off his grimy cheeks. “I’ve cracked the archive,” he muttered, fingers dancing over a rusted keyboard. “The old security cams are buried under the basement tiles. If any feed captured June 12 2004, we’ll see it.”  

Maya stepped closer, the air tasting of cold steel and damp cement. “You think the fire was recorded?” she asked, voice swallowed by the tunnel’s echo.  

Javi’s eyes flicked to a cracked monitor mounted on the wall. “There’s a feed labeled ‘Night‑Shift 7’ from 02:36 am to 02:38 am. It cuts out at 02:37 am—right when the fire alarm tripped.” He pressed play.  

The grainy footage crackled to life: a black‑and‑white smear of a hallway lit by flickering fluorescents. A lone figure in a high‑visibility vest, name tag half‑erased, approached a steel door stamped with the number “7.” The camera wavered as the worker’s gloved hand brushed the door, the metal groaning under the touch.  

A burst of static spiked the screen, then the image froze. A pale outline of a face—eyes wide, mouth open in a silent scream—flashed across the doorway before the picture dissolved into jagged noise. The timestamp blinked: **02:37 am, 12‑06‑2004**.  

Maya felt a cold prickle rise along her spine. “That’s the exact minute the alarm went off.”  

Ethan leaned in, brow furrowed. “Who was that? And why does the camera cut the instant they open the door?”  

Javi scrolled, searching for another angle. The feed stuttered, then a ceiling‑mounted camera clicked into view, showing a shadowed alcove where a stack of steel drums stood. The same worker paused, turned, and slipped a small brass key into a recessed panel beside the drums. The key glinted momentarily before the feed sputtered and died.  

“E‑9,” Javi whispered, recalling the cryptic note from the maintenance log. “That panel must be the trigger for V‑9. Whoever—” He stopped, eyes widening. “The key bears the same gear‑serpent motif we saw on the ECH plate, linking it to the hidden mechanism.”  

Maya’s breath caught. “Selene’s research mentioned a ‘gateway key.’ She thought it could lock the echo in place.” She stared at the frozen image, the worker’s hand still half‑in the panel, the door yawning behind them. “If they turned the valve that night…”  

A low, resonant hum rose from the concrete, matching the building’s old fire alarm frequency. The V‑9 handle twitched as if caught in an invisible current. Ethan gripped the rail, knuckles white. “We have to find that key now, before the valve re‑engages on its own.”  

Javi shut the laptop, the screen going black. “The key isn’t just a key. On its shank is a serial number—B‑742‑9—exactly the same as the ledger entry we found in the basement box.” He glanced at the rusted notebook still tucked in his bag. “Victor’s payout was for that exact item.”  

Maya swallowed, the weight of the moment settling like dust on her shoulders. “If the key can shut V‑9, it might also lock whatever’s on that floor. But if it’s missing…”  

A metallic clang reverberated from the elevator shaft, rhythmic and deliberate.  

Ethan’s voice cracked. “What if someone already has the key and is using it to keep the floor alive?”  

The hallway lights flickered, casting long shadows that stretched toward the sealed door. In the half‑light, a faint outline of a figure hovered just beyond the doorway—pale, translucent, eyes wide with urgency. It was Selene, her ghostly form shimmering like static.  

Maya turned, heart hammering. “Selene?” she whispered.  

The specter opened its mouth, but no sound emerged from the air. Instead, a thin, unmistakable voice seemed to echo from the hidden floor itself, threading through the hum and the clang: **“Turn.”**


---

# Episode 14: Echoes in the Steel

The hallway beyond the sealed door pulsed with a low, metallic thrum that seemed to sync with Maya’s breath. She pressed the brass key—B‑742‑9—against the cold metal of the lock, feeling the familiar ridges beneath her fingertips. The lock turned with a reluctant click, and the heavy steel doors shivered open, spilling a thin veil of stale, lead‑scented air onto the concrete floor.

A faint, wavering light flickered from the far wall, coalescing into the faint outline of Dr. Selene Patel. Her form was translucent, a shimmering silhouette that could not grasp the world, but her presence pressed against Maya’s mind like a question.

“Do you see the readings?” Selene’s voice drifted, a resonance that seemed to come from the walls themselves rather than her lips. The EMF meters Maya had left on a nearby workbench flickered to life without any touch, their green needles dancing in unison. A thin line of static projected onto the wall, tracing a sine wave that matched the old fire alarm’s 120‑Hz carrier.

Maya swallowed. “The fire alarm circuit is still tied into the elevator’s control bus. If the lift stops here during a blackout, it could feed back into the analog panel.”

Selene’s eyes, hollow yet fierce, glowed brighter. “Exactly. The resonance will force the doors to open and close on a floor that isn’t supposed to exist. The pressure will spike, the conduit will burst—”

A sudden, sharp clang reverberated from deeper within the shaft, followed by a low, metallic whine. Maya’s hand tightened around the key. “What’s that?”

The ghost’s hand pointed—without touching—to a series of etched symbols on the far wall that Maya had never noticed. Between the familiar gear‑serpent motif and the rusted panel, a fresh glyph glowed a sickly green: a stylized “E‑9” surrounded by a spiraling vortex.

“Secondary conduit activation,” Selve whispered. “XR‑7‑8422 is feeding into V‑9 now. If it reaches full pressure, it will force the floor to lock us in.”

Maya’s eyes darted to the conduit hatch she had documented in the maintenance log. The brass cover was ajar, a thin stream of chilled air escaping like a sigh. The glyph’s glow pulsed in time with the humming from the shaft, each beat louder than the last.

She took a step onto the concrete, the cold floor sending a shiver up her spine. Instantly, a flash seized her vision—sepia‑toned, fleeting. She was no longer in the hallway but standing amid the 2004 disaster. The air was thick with ash; men in yellow hard hats shouted over the roar of a sudden explosion. A worker’s face—young, eyes wide—locked onto hers before a plume of black smoke swallowed everything. The memory surged, then fractured, leaving Maya gasping on the floor of the hidden level.

The echo faded, but the glyph’s light intensified, casting long shadows that crawled across the wall. Selene’s specter hovered closer, though still unable to touch. “You have the key, Maya. Use it on the relay for the new conduit. It will shut the feed long enough to isolate the fire alarm loop.”

Maya knelt beside the hatch, the key already in her palm. She aligned the brass teeth with the recessed slot marked “E‑9” on the relay. The lock turned with a metallic grind, the sound reverberating through the steel bones of the floor. As the key slipped home, the humming from the shaft dropped an octave, then steadied into a low, steady thrum.

A crackle crackled over the building’s intercom, startling Maya. Lena Ortiz’s voice, crisp and unnervingly calm, filled the corridor. “All night‑shift staff, be advised: a surprise inspection of the elevator control room will commence at 04:15. All logs, schematics, and access codes must be submitted to my office beforehand. Non‑compliance will result in immediate suspension.”

Maya’s throat tightened. The inspection meant Lena would be in the control room, where the analog panel lay exposed. If Lena discovered the modifications, the whole operation could be undone.

She stood, the key still warm against her palm, and glanced back at Selene. The ghost’s outline flickered, a warning rippling through the air. “You’re not alone down there,” Selene murmured, her voice a thin thread of static. “Someone else is already inside the control board.”

A soft, metallic click echoed from above, distant yet unmistakable. Maya’s heart slammed against her ribs as a shadow moved across the ceiling tiles of the elevator shaft, a figure hunched over the main board, fingers dancing over switches.

The hallway lights sputtered, and for a heartbeat the glyph on the wall flared brighter than the emergency bulbs could ever shine.

“What…?” Maya whispered, breath fogging in the cold air, as the figure’s silhouette paused, turned, and a single, familiar scarred hand lifted—Victor Hale’s, holding a screwdriver that glinted with a faint, otherworldly sheen.


---

# Episode 15: **The Brief Lock**

The staff lounge hummed with the low thrum of the building’s aging ventilation as the wall clock blinked 03:42 am. Maya stood beside the stainless‑steel counter, the brass key still warm against her palm, while Ethan shuffled yellowed logs onto a metal tray. A faint smell of burnt coffee mingled with the metallic tang of oil that always lingered after a power dip.

Lena Ortiz entered, heels striking the tile with metronomic precision. She carried a clipboard like a shield, her smile calibrated to corporate calm. “All night‑shift personnel, attention,” she announced, voice amplified through the intercom, “the surprise inspection I mentioned earlier will begin at 04:15. I need every maintenance log, every access code, and every anomaly report submitted to my office before then. Failure to comply will result in immediate suspension.”

A murmur rose from the assembled crew. Maya felt the 33‑minute window tighten like a vice around her throat. She glanced at Ethan; his eyes flicked toward the service tunnel where the hatch to Level 7 yawned like a dark mouth.

Lena placed a thin folder on the desk and tapped it lightly. The lid sighed open, revealing a single sheet of half‑crumpled paper. In the center, a faint schematic was sketched in charcoal: the outline of conduit XR‑7‑8423, its terminal marked with a jagged slash. Over the drawing, a gear‑serpent motif was half‑drawn, its teeth missing, leaving a hollow that matched the key’s cut.

Maya’s breath caught. The sketch was not a symbol but a partial map. If the key’s teeth aligned with the missing teeth of the gear, the overlay could form a code—an override sequence that might force the analog panel to reject a non‑existent floor.

She slipped the key into the slot of the nearby service panel, feeling the metal bite into the analog lock. A low click resonated, and the green‑lit indicator on the panel flickered off for a heartbeat before the system re‑engaged. The brief silence was a gasp of possibility.

“Did you just…?” Lena’s voice cut through, sharp as a scalpel. She stepped forward, eyes narrowing on the paper. “What are you doing, Maya?”

Before Maya could answer, the glass wall that separated the lounge from the elevator shaft rippled. A pale outline coalesced—Dr. Selene Patel, hair floating in a wind no one else felt, eyes wide with urgent desperation.

Selene’s voice was a thin thread of static, barely louder than the ventilation hum. “Maya, the conduit XR‑7‑8423 feeds the hidden floor’s power buffer. That schematic isn’t a lock; it’s a bypass. If you combine the key with the missing gear teeth, you get the reset code—E‑9‑R‑S‑E‑T. It will force the elevator to reject any stop at Level 7, but only while the analog lock is held open.”

Lena snapped her clipboard shut, the sound cracking the ghostly murmur. “We’re dealing with paperwork, not… specters,” she said, though her jaw tightened.

Selene’s silhouette trembled, the edges shimmering like heat on a summer road. “The floor is alive when the power falters. If they write this code into the system, the hidden floor will become a trap—locking anyone who steps inside forever. Victor’s screwdriver can override the lock, but without the reset code the floor will seal itself.”

A metallic clang echoed from the service tunnel—someone forcing a door. Ethan burst out, flashlight sweeping the gloom. The beam landed on the hatch to Level 7, now ajar, a faint green glow seeping out like wounded flesh.

Maya’s fingers tightened around the brass key. The paper’s schematic pulsed under the fluorescent light, the missing teeth of the gear aligning perfectly with the key’s cuts. She whispered, “E‑9‑R‑S‑E‑T.” The letters seemed to glow for an instant, then faded as the analog lock clicked back into place, sealing the panel.

Lena leaned in, voice icy. “Hand over the key, Maya. If you keep it, you jeopardize the inspection. If you give it up, we all lose.”

Selene’s ghost drifted closer, her hand hovering over the paper as if to press the ink itself. “Don’t let them file the override,” she urged, her voice cracking. “If they do, the floor will never close. It will keep feeding on anyone who dares to enter.”

Maya stared at the folded paper, the partial schematic still half‑visible, and felt the weight of the decision pressing against the ticking clock. The elevator above shuddered, a low groan hinting at an impending power surge.

She lifted her gaze, meeting Lena’s stare, then the translucent eyes of Selene. The paper trembled in the draft, and a second, smaller slip slipped from beneath it—a single line of handwritten code: **“XR‑7‑8423‑RESET.”** 

If she could input that before the inspection, could she stop Victor’s sabotage and keep the hidden floor from becoming a prison?
