# Human-in-the-loop log

- **ep 0 / plan_feedback**: change the setting to a village with a new building and not a city
- **ep 0 / plan_approved**: 
- **ep 2 / reject**: end on a scary cliffhanger
- **ep 4 / feedback**: bring in the expert doctor in episode 4 kill her before any conclusion is reached and bring her back as a ghost in a later episode
  - directive: Any character killed may only return as a supernatural presence; permanent deaths are limited to non‑core characters.
  - beats rewritten: [4, 5]
- **ep 4 / edit**: human edited the episode text before approval
- **ep 6 / feedback**: Bring the ghost of the doctor in the next 2 episodes but make it look like the ghost needs time to manifest fully and the protagonists are jump scared initially
  - beats rewritten: [15, 16]
- **ep 7 / edit**: manual edit after approval: inserted 2 jump scares (face at the vent grille; woman's shape in the dust + recorder whisper) so Selene's ghost begins to manifest gradually — applies feedback@ep6
- **ep 8 / edit**: manual edit after approval: inserted 1 jump scare (scorched sleeve in the panel reflection) — ghost manifestation continues per feedback@ep6
- **ep 10 / edit**: manual edit after approval: completed the truncated ending ('A sudden pressure pressed…') — sets up ep 11 (Ethan to the vents, Maya to the north water heater)
- beat 4 before feedback 'bring in the expert doctor in episode 4 kill her before any conclusion is reached and bring her back as a ghost in a later episode': Javi Ramos, a rookie electrician, discovers a rusted door tucked behind a maintenance closet that bears the number 7 etched faintly on its frame.
- beat 5 before feedback 'bring in the expert doctor in episode 4 kill her before any conclusion is reached and bring her back as a ghost in a later episode': Dr. Selene Patel arrives to consult on the building's historic infrastructure; she mentions a 2004 industrial accident at a “sealed level” but admits records are missing.
- beat 15 before feedback 'Bring the ghost of the doctor in the next 2 episodes but make it look like the ghost needs time to manifest fully and the protagonists are jump scared initially': Lena Ortiz calls an emergency staff meeting, demanding all night‑shift logs be submitted, and subtly threatens Maya with a disciplinary review.
- beat 16 before feedback 'Bring the ghost of the doctor in the next 2 episodes but make it look like the ghost needs time to manifest fully and the protagonists are jump scared initially': Victor Hale is seen late at night adjusting the elevator’s main control board, briefly overriding the analog lock that prevents stops at non‑existent floors.
